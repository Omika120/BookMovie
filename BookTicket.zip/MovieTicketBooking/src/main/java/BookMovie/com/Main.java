package BookMovie.com;

import java.util.Scanner;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        UserDao userDao = new UserDao();
        MovieDao movieDao = new MovieDao();
        BookingDao bookingDao = new BookingDao();

        while (true) {
            System.out.println("\n--- Movie Ticket Booking System ---");
            System.out.println("1. User Management");
            System.out.println("2. Movie Management");
            System.out.println("3. Booking Management");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int mainChoice = sc.nextInt();

            switch (mainChoice) {
                case 1:
                    userManagementMenu(sc, userDao);
                    break;

                case 2:
                    movieManagementMenu(sc, movieDao);
                    break;

                case 3:
                    bookingManagementMenu(sc, bookingDao, movieDao);
                    break;

                case 4:
                    System.out.println("Exiting... Thank you!");
                    sc.close();
                    System.exit(0);

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    // User Management Menu
    private static void userManagementMenu(Scanner sc, UserDao userDao) {
        while (true) {
            System.out.println("\n--- User Management ---");
            System.out.println("1. Register User");
            System.out.println("2. List All Users");
            System.out.println("3. Update User Details");
            System.out.println("4. Delete User");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int userChoice = sc.nextInt();

            switch (userChoice) {
                case 1:
                    System.out.println("Enter User ID, Name, Email:");
                    int id = sc.nextInt();
                    sc.nextLine(); // Consume newline
                    String name = sc.nextLine();
                    String email = sc.nextLine();
                    userDao.registerUser(new User(id, name, email));
                    System.out.println("User registered successfully.");
                    break;

                case 2:
                    List<User> users = userDao.listAllUsers();
                    System.out.println("All Registered Users:");
                    for (User user : users) {
                        System.out.println("ID: " + user.getId() + ", Name: " + user.getName() + ", Email: " + user.getEmail());
                    }
                    break;

                case 3:
                    System.out.println("Enter User ID to Update:");
                    int updateId = sc.nextInt();
                    sc.nextLine(); // Consume newline
                    User userToUpdate = userDao.listAllUsers()
                            .stream().filter(u -> u.getId() == updateId)
                            .findFirst().orElse(null);
                    if (userToUpdate != null) {
                        System.out.println("Enter New Name and Email:");
                        userToUpdate.setName(sc.nextLine());
                        userToUpdate.setEmail(sc.nextLine());
                        userDao.updateUser(userToUpdate);
                        System.out.println("User details updated successfully.");
                    } else {
                        System.out.println("User not found.");
                    }
                    break;

                case 4:
                    System.out.println("Enter User Name to Delete:");
                    sc.nextLine(); // Consume newline
                    String userNameToDelete = sc.nextLine();
                    userDao.deleteUser(userNameToDelete);
                    System.out.println("User deleted successfully.");
                    break;

                case 5:
                    return;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    // Movie Management Menu
    private static void movieManagementMenu(Scanner sc, MovieDao movieDao) {
        while (true) {
            System.out.println("\n--- Movie Management ---");
            System.out.println("1. Add Movie");
            System.out.println("2. List All Movies");
            System.out.println("3. Check Seats Available");
            System.out.println("4. Delete Movie");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int movieChoice = sc.nextInt();

            switch (movieChoice) {
                case 1:
                    System.out.println("Enter Movie Title, Price, Seats Available:");
                    sc.nextLine(); // Consume newline
                    String title = sc.nextLine();
                    double price = sc.nextDouble();
                    int seats = sc.nextInt();
                    movieDao.addMovie(new Movie(title, price, seats));
                    System.out.println("Movie added successfully.");
                    break;

                case 2:
                    List<Movie> movies = movieDao.listAllMovies();
                    System.out.println("Available Movies:");
                    for (Movie movie : movies) {
                        System.out.println("Title: " + movie.getTitle() + ", Price: " + movie.getPrice() + ", Seats: " + movie.getSeatsAvailable());
                    }
                    break;

                case 3:
                    System.out.println("Enter Movie Title to Check Seats:");
                    sc.nextLine(); // Consume newline
                    String movieTitle = sc.nextLine();
                    int availableSeats = movieDao.getSeatsAvailable(movieTitle);
                    System.out.println("Seats Available for " + movieTitle + ": " + availableSeats);
                    break;

                case 4:
                    System.out.println("Enter Movie Title to Delete:");
                    sc.nextLine(); // Consume newline
                    String movieTitleToDelete = sc.nextLine();
                    movieDao.deleteMovie(movieTitleToDelete);
                    System.out.println("Movie deleted successfully.");
                    break;

                case 5:
                    return;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    // Booking Management Menu
    private static void bookingManagementMenu(Scanner sc, BookingDao bookingDao, MovieDao movieDao) {
        while (true) {
            System.out.println("\n--- Booking Management ---");
            System.out.println("1. Book Ticket");
            System.out.println("2. Cancel Booking");
            System.out.println("3. View All Bookings");
            System.out.println("4. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int bookingChoice = sc.nextInt();

            switch (bookingChoice) {
                case 1: // Book Ticket
                    System.out.println("Enter User Name and Movie Title to Book:");
                    sc.nextLine(); // Consume newline
                    String bookingUserName = sc.nextLine();
                    String bookingMovieTitle = sc.nextLine();
                    if (movieDao.getSeatsAvailable(bookingMovieTitle) > 0) {
                        Booking newBooking = new Booking(bookingUserName, bookingMovieTitle);
                        bookingDao.bookTicket(newBooking);

                        // Fetch and print the booking ID
                        System.out.println("Ticket booked successfully. Booking ID: " + newBooking.getId());

                        // Update movie seats
                        movieDao.updateSeats(bookingMovieTitle, movieDao.getSeatsAvailable(bookingMovieTitle) - 1);
                    } else {
                        System.out.println("No seats available.");
                    }
                    break;


                case 2:
                    System.out.println("Enter Booking ID to Cancel:");
                    int bookingId = sc.nextInt();
                    bookingDao.cancelBooking(bookingId);
                    break;

                case 3:
                    List<Booking> bookings = bookingDao.viewAllBookings();
                    System.out.println("All Bookings:");
                    for (Booking booking : bookings) {
                        System.out.println("Booking ID: " + booking.getId() + ", User: " + booking.getUserName() + ", Movie: " + booking.getMovieTitle());
                    }
                    break;

                case 4:
                    return;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
